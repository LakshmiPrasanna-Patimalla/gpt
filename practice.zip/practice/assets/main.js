import { marked } from 'marked';

window.marked = marked;
