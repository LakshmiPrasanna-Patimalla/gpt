import { marked } from 'marked';

window.marked = marked;  // Expose it to the browser so your template can use it
