from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    path('', views.chat_interface, name='chat_interface'),
    path('login/', auth_views.LoginView.as_view(template_name='webs/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='login'), name='logout'),

    # Chat session management
    path("chat/clear/", views.clear_chat_history, name="clear_chat_history"),
    path('chat/create/', views.create_chat_session, name='create_chat'),
    path('chat/delete/', views.delete_chat_session, name='delete_chat'),
    path('chat/rename/', views.rename_chat_session, name='rename_chat'),

    # Chat content and streaming
    path('chat/history/<int:chat_id>/', views.get_chat_history, name='get_chat_history'),
    path('chat/stream/', views.stream_message, name='stream_message'),

    # Settings
    path('chat/update-session/', views.update_current_session_settings, name='update_session_settings'),

]
