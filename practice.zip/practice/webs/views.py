from django.shortcuts import render, get_object_or_404 , redirect
from django.http import JsonResponse, StreamingHttpResponse
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.decorators import login_required
from django.conf import settings
from .models import ChatSession, Message
from openai import OpenAI
import json
import time
import base64
from django.core.files.uploadedfile import InMemoryUploadedFile

client = OpenAI(api_key=settings.OPENAI_API_KEY)

# ---------------------- Interface View ----------------------

@login_required
def chat_interface(request):
    sessions = ChatSession.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'webs/chat_interface.html', {
        'sessions': sessions,
        'initial_session_id': None
    })

# ---------------------- Chat Session Management ----------------------

@csrf_exempt
@login_required
def create_chat_session(request):
    if request.method == 'POST':
        session = ChatSession.objects.create(
            user=request.user,
            title=f"Session {ChatSession.objects.filter(user=request.user).count() + 1}"
        )
        return JsonResponse({'id': session.id})

@csrf_exempt
@login_required
def delete_chat_session(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        session_id = data.get('session_id')
        ChatSession.objects.filter(id=session_id, user=request.user).delete()
        return JsonResponse({'status': 'deleted'})
@csrf_exempt
@login_required
def clear_chat_history(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        session_id = data.get('session_id')

        try:
            session = ChatSession.objects.get(id=session_id, user=request.user)
        except ChatSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)

        # Delete only messages from the session
        Message.objects.filter(chat_session=session).delete()
        return JsonResponse({'status': 'chat_cleared'})

    return JsonResponse({'error': 'Invalid method'}, status=405)

@csrf_exempt
@login_required
def rename_chat_session(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        session_id = data.get('session_id')
        new_title = data.get('new_title')

        session = get_object_or_404(ChatSession, id=session_id, user=request.user)
        session.title = new_title
        session.save()

        return JsonResponse({'status': 'renamed', 'new_title': session.title})

# ---------------------- Chat History ----------------------

@login_required
def get_chat_history(request, chat_id):
    session = get_object_or_404(ChatSession, id=chat_id, user=request.user)
    messages = session.messages.order_by('timestamp').values('role', 'content')
    return JsonResponse(list(messages), safe=False)

# ---------------------- Streaming GPT Response ----------------------

@csrf_exempt
@login_required
def stream_message(request):
    if request.method != 'POST':
        return JsonResponse({'error': 'POST request required'}, status=405)

    session_id = request.POST.get("session_id")
    user_message = request.POST.get("message")
    image_file = request.FILES.get("image")

    if not session_id or not user_message:
        return JsonResponse({'error': 'Missing session_id or message'}, status=400)

    session = get_object_or_404(ChatSession, id=session_id, user=request.user)
    Message.objects.create(chat_session=session, role='user', content=user_message)

    def generate():
        buffer = ""
        try:
            history = [
                {"role": msg.role, "content": msg.content}
                for msg in session.messages.order_by('timestamp')
            ]

            # Prepare system message
            system_prompt = {
                "role": "system",
                "content": (
                    "You are a helpful assistant. Always format all code examples using triple backticks (```) and "
                    "a valid language tag (e.g. ```python). Use Markdown headings, bullet points, and blank lines "
                    "for readability."
                )
            }

            # Text-only message case
            if not image_file:
                history.append({"role": "user", "content": user_message})

                response = client.chat.completions.create(
                    model=session.model,
                    messages=[system_prompt] + history,
                    temperature=session.temperature,
                    stream=True
                )
            else:
                # If image is provided: encode and prepare multimodal input
                image_data = base64.b64encode(image_file.read()).decode("utf-8")
                multimodal_content = [
                    user_message,
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{image_data}",
                            "detail": "low"
                        }
                    }
                ]

                history.append({"role": "user", "content": multimodal_content})

                response = client.chat.completions.create(
                    model=session.model,
                    messages=[system_prompt] + history,
                    temperature=session.temperature,
                    stream=True
                )

            for chunk in response:
                token = getattr(chunk.choices[0].delta, "content", None)
                if token:
                    buffer += token
                    yield f"data: {token}\n\n"
                    time.sleep(0.02)

        except Exception as e:
            yield f"data: ⚠️ Error from OpenAI: {e}\n\n"

        if buffer.strip():
            Message.objects.create(chat_session=session, role='assistant', content=buffer)

    return StreamingHttpResponse(generate(), content_type='text/event-stream')

from django.http import JsonResponse
from .models import UserSetting

from django.views.decorators.csrf import csrf_exempt
from django.http import JsonResponse
from .models import ChatSession

@login_required
@csrf_exempt
def update_current_session_settings(request):
    if request.method == 'POST':
        session_id = request.POST.get('session_id')
        if not session_id:
            return JsonResponse({'error': 'Missing session_id'}, status=400)

        try:
            session = ChatSession.objects.get(id=session_id, user=request.user)
        except ChatSession.DoesNotExist:
            return JsonResponse({'error': 'Session not found'}, status=404)

        if 'temperature' in request.POST:
            session.temperature = float(request.POST['temperature'])

        if 'model' in request.POST:
            session.model = request.POST['model']



        session.save()
        print(session.temperature)
        return JsonResponse({'status': 'updated'})

    return JsonResponse({'error': 'Invalid method'}, status=405)
