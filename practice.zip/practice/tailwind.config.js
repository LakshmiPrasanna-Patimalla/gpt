module.exports = {
  content: [
    "./templates/**/*.html",
    "./webs/templates/**/*.html",
    "./static/**/*.js",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
