export default {
  build: {
    outDir: 'static/js',
    rollupOptions: {
      input: 'assets/main.js'
    }
  }
}
